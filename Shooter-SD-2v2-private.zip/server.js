const http = require('http');
const fs = require('fs');
const path = require('path');
const WebSocket = require('ws');

const PORT = process.env.PORT || 3000;
const ROOT = __dirname;
const rooms = new Map();
const ALPHABET = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';

function code() {
  let s = '';
  do { s = Array.from({length:5}, () => ALPHABET[Math.floor(Math.random()*ALPHABET.length)]).join(''); }
  while (rooms.has(s));
  return s;
}
function send(ws, obj) { if (ws.readyState === WebSocket.OPEN) ws.send(JSON.stringify(obj)); }
function broadcast(room, obj, except) {
  for (const p of room.players.values()) if (p.ws !== except) send(p.ws, obj);
}
function roomState(room) {
  return [...room.players.values()].sort((a,b)=>a.slot-b.slot).map(p=>({id:p.id,slot:p.slot,name:p.name,team:p.team,host:p.host}));
}
function sendLobby(room) {
  broadcast(room, {type:'lobby', code:room.code, host:room.hostId, players:roomState(room), started:room.started});
}
function freeSlot(room) {
  for (let i=0;i<4;i++) if (![...room.players.values()].some(p=>p.slot===i)) return i;
  return -1;
}
function closePlayer(room, p) {
  room.players.delete(p.id);
  if (room.hostId === p.id) {
    room.hostId = room.players.size ? [...room.players.values()][0].id : null;
    for (const q of room.players.values()) q.host = q.id === room.hostId;
    if (room.hostId) send(room.players.get(room.hostId).ws, {type:'host_changed'});
  }
  if (!room.players.size) rooms.delete(room.code); else sendLobby(room);
}

const server = http.createServer((req,res)=>{
  let u = decodeURIComponent((req.url||'/').split('?')[0]);
  if (u === '/') u = '/index.html';
  const file = path.join(ROOT, u);
  if (!file.startsWith(ROOT) || !fs.existsSync(file) || fs.statSync(file).isDirectory()) {
    res.writeHead(404); return res.end('Not found');
  }
  const ext = path.extname(file);
  const types = {'.html':'text/html; charset=utf-8','.js':'application/javascript; charset=utf-8','.css':'text/css; charset=utf-8','.json':'application/json'};
  res.writeHead(200, {'Content-Type':types[ext]||'application/octet-stream','Cache-Control':'no-store'});
  fs.createReadStream(file).pipe(res);
});

const wss = new WebSocket.Server({server});
wss.on('connection', ws => {
  const client = {ws,id:Math.random().toString(36).slice(2),room:null,slot:-1,name:'Joueur'};
  ws.on('message', raw => {
    let m; try { m=JSON.parse(raw); } catch { return; }
    if (m.type === 'create') {
      if (client.room) return;
      const c=code(), room={code:c,hostId:client.id,players:new Map(),started:false};
      rooms.set(c,room); client.room=room;client.slot=0;client.name=String(m.name||'Hôte').slice(0,18);
      client.team=0;client.host=true;room.players.set(client.id,client);
      send(ws,{type:'created',code:c,id:client.id,slot:0,team:0,host:true});sendLobby(room);return;
    }
    if (m.type === 'join') {
      if (client.room) return;
      const c=String(m.code||'').trim().toUpperCase(),room=rooms.get(c);
      if (!room) return send(ws,{type:'error',message:'Partie introuvable.'});
      if (room.started) return send(ws,{type:'error',message:'La partie a déjà commencé.'});
      const slot=freeSlot(room); if(slot<0)return send(ws,{type:'error',message:'Partie complète.'});
      client.room=room;client.slot=slot;client.name=String(m.name||'Joueur').slice(0,18);client.team=slot<2?0:1;client.host=false;room.players.set(client.id,client);
      send(ws,{type:'joined',code:c,id:client.id,slot,team:client.team,host:false});sendLobby(room);return;
    }
    const room=client.room;if(!room)return;
    if (m.type === 'start') {
      if(client.id!==room.hostId)return;
      room.started=true; broadcast(room,{type:'start',players:roomState(room)}); return;
    }
    if (m.type === 'input') {
      if(client.id!==room.hostId && room.started) {
        const host=room.players.get(room.hostId); if(host) send(host.ws,{type:'remote_input',slot:client.slot,input:m.input||{}});
      }
      return;
    }
    if (m.type === 'state') {
      if(client.id!==room.hostId || !room.started)return;
      broadcast(room,{type:'state',state:m.state}); return;
    }
    if (m.type === 'leave') { closePlayer(room,client); client.room=null; }
  });
  ws.on('close',()=>{if(client.room)closePlayer(client.room,client);});
});

server.listen(PORT,()=>console.log(`Search & Destroy server listening on http://localhost:${PORT}`));
